import uuid

print(uuid.uuid4())